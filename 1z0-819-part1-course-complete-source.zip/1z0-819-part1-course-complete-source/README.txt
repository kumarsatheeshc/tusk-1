Thanks for investing in my Oracle Java SE 11 Programmer exam course covering 1Z0-815.

This is the zip file containing all the source code.

Just unzip the file and you will find zip files for each lecture in the course, each broken down into their respective sections.

The very last video in the course has details of how to download the slides, so check that out if you want to download the slides.

That lecture includes a bonus PDF so be sure to click Resources when playing the video.

If you got this file anywhere other than from Udemy, its been uploaded without my authorization. I've spent a lot of time researching the information necessary to put this course together and of course recording the videos. Please do the right thing and buy the course
if you find it useful. If you've seen a picture of me, you know I like eating, so buying the course if you have not already will ensure I get to continue eating (as well as my family of course).

Here is a link that will enable you to grab the course at a massively discounted price.

https://learnprogramming.academy/courses/java-se-11-programmer-exam-course-oracle-1z0-815/

If you have any questions leave a question in the Q&A section of the course, or send me a message on Udemy.  Here is my profile

https://www.udemy.com/user/timbuchalka/

Alternatively send me an email at courses@learnprogramming.academy

Regards

Tim Buchalka (course creator)
Adelaide, Australia
January 14th, 2020